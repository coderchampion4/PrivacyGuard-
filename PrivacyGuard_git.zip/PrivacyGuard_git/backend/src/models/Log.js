import mongoose from "mongoose";
const schema=new mongoose.Schema({perms:Object,fingerprint:String},{timestamps:true});
export default mongoose.model("Log", schema);
