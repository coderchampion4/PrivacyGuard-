import express from "express";
import Log from "../models/Log.js";
const r=express.Router();
r.get("/", async (_,res)=>res.json(await Log.find().sort({createdAt:-1})));
r.post("/", async (req,res)=>res.json(await new Log(req.body).save()));
export default r;
