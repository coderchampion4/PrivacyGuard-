import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import dotenv from "dotenv";
import historyRoutes from "./routes/history.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use("/api/history", historyRoutes);

// ✅ Permissions API route (dummy data for testing)
app.get("/api/permissions", (req, res) => {
  res.json({
    permissions: [
      { type: "Camera", status: "granted" },
      { type: "Microphone", status: "denied" },
      { type: "Location", status: "prompt" }
    ]
  });
});

// Connect to MongoDB and start server
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => {
    app.listen(PORT, () => {
      console.log(`🚀 Backend running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error("MongoDB connection error:", err.message);
  });
