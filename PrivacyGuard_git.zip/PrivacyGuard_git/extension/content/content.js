(async () => {
  const permissions = {
    geolocation: 'prompt',
    camera: 'prompt',
    microphone: 'prompt',
    notifications: 'prompt'
  };

  try {
    for (const name of Object.keys(permissions)) {
      const status = await navigator.permissions.query({ name });
      permissions[name] = status.state; // 'granted' | 'denied' | 'prompt'
    }
  } catch (err) {
    console.error("Permission query error:", err);
  }

  chrome.runtime.sendMessage({
    type: "PERMISSIONS_DATA",
    data: permissions
  });
})();
