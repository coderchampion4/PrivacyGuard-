export async function query() {
  const types = ["camera","microphone","geolocation","notifications"];
  const res = {};
  for(const t of types){
    try{res[t]=(await navigator.permissions.query({name:t})).state;}
    catch{res[t]="unsupported";}
  }
  return res;
}
