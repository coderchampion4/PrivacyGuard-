async function load() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.runtime.sendMessage({ type: "GET_PERMISSIONS", tabId: tab.id }, (res) => {
    const container = document.getElementById("perms");
    if (!res || !res.data) {
      container.innerHTML = "<p>No permissions found</p>";
      return;
    }

    container.innerHTML = Object.entries(res.data)
      .map(([key, val]) => `<div><strong>${key}</strong>: ${val}</div>`)
      .join("");
  });
}

load();
