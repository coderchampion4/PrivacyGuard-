chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "PERMISSIONS_DATA") {
    const tabId = sender.tab?.id;
    if (tabId !== undefined) {
      chrome.storage.local.set({ [tabId]: message.data });
    }
  }

  if (message.type === "GET_PERMISSIONS") {
    const tabId = message.tabId;
    if (tabId !== undefined) {
      chrome.storage.local.get([tabId.toString()], (result) => {
        sendResponse({ data: result[tabId] || {} });
      });
      return true;
    } else {
      sendResponse({ data: {} });
    }
  }
});
