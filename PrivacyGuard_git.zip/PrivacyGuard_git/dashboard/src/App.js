import React, { useEffect, useState } from "react";
import PermissionCard from "./components/PermissionCard";

function App() {
  const [permissions, setPermissions] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/permissions")
      .then((res) => res.json())
      .then((data) => setPermissions(data.permissions || []))
      .catch((err) => console.error("Failed to fetch permissions", err));
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <h1 className="text-4xl font-bold mb-6">🔐 PrivacyGuard Dashboard</h1>
      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
        {permissions.length === 0 ? (
          <p>No permissions found or server not running.</p>
        ) : (
          permissions.map((perm, idx) => (
            <PermissionCard key={idx} type={perm.type} status={perm.status} />
          ))
        )}
      </div>
    </div>
  );
}

export default App;