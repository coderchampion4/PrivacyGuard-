import React from "react";

const PermissionCard = ({ type, status }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h2 className="text-lg font-semibold">{type}</h2>
      <p
        className={`mt-1 text-sm ${
          status === "granted" ? "text-green-400" : "text-red-400"
        }`}
      >
        {status.toUpperCase()}
      </p>
    </div>
  );
};

export default PermissionCard;
